from ultralytics import YOLO
import cv2


# Load your trained YOLOv8 model
model = YOLO("best.pt")  # Replace with your model path

# Open webcam (0 for default camera)
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    
    results = model.predict(frame, conf=0.55)  

    # Draw bounding boxes
    frame = results[0].plot()

    # Show output
    cv2.imshow("YOLOv8 Webcam Detection", frame)

    # Press 'q' to exit
    if cv2.waitKey(1) & 0xFF == 27:  # 27 is the ASCII code for ESC
        break

cap.release()
cv2.destroyAllWindows()